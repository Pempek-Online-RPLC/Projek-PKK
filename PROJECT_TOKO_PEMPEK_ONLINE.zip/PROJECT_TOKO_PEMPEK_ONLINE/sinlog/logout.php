<?php 
//menjalankan session : selalu diletakkan di awal
session_start();
//menghapus session username dan level
unset($_SESSION['username']);
unset($_SESSION['status']);
//mengapus semua session dari browser
session_destroy();

echo "<script>
				alert('Berhasil logout !');
				document.location='login.php';
		  </script>";

?>