<?php 
    include "../koneksi/koneksi.php";
    session_start();
    //register
    if(isset($_POST['register'])){
        //jika tombol register diklik

        $username=$_POST["username"];
        $password=$_POST["password"]; //inputan user belum dienkripsi
        $nama_lengkap=$_POST["nama_lengkap"];
        $jenis_kelamin=$_POST["jenis_kelamin"];
        $tanggal_lahir=$_POST["tanggal_lahir"];
        $alamat=$_POST["alamat"];
        $hp=$_POST["hp"];
        $status= "user";

        //fungsi enkripsi
        $epassword = password_hash($password, PASSWORD_DEFAULT);

        //insert to db
        $insert = mysqli_query($koneksi,"INSERT INTO user (username,password,nama_lengkap,jenis_kelamin,tanggal_lahir,alamat,hp,status) VALUES('$username','$epassword','$nama_lengkap','$jenis_kelamin','$tanggal_lahir','$alamat','$hp','$status')");

        if($insert){
            //jika berhasil
            echo "<script>
				alert('Anda Berhasil Registrasi !');
				document.location='login.php';
		  </script>";
        } else {
            //jika gagal
            echo "<script>
				alert('Registrasi Anda Gagal !');
				document.location='register.php';
		  </script>";
        }
    }

    //login
    if(isset($_POST['submit'])) {
        $user = $_POST['username'];
        $password = $_POST['password'];

        // Query untuk memilih tabel
        $cekdb = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$user'");
        $pw = mysqli_fetch_array($cekdb);
        $hitung = mysqli_num_rows($cekdb);
        $passwordsekarang = $pw['password'];
        $status = $pw['status'];
        $login_user = $pw['username'];

        // Pengecekan Kondisi Login Berhasil/Tidak
          if ($hitung > 0) {
              //jika ada
              //verifikasi password
              if(password_verify($password,$passwordsekarang)){
                //jika password benar

                $_SESSION['login_user'] = $login_user;
                //mengecek status
                if ($status == 'admin') {
                    header('location: ../admin_page/produk_admin.php');
                  }elseif ($status == 'user') {
                    //Penggunaan javascript
echo "<script>var elm = document.getElementById('sinlog');
elm.style.display = 'none';</script>";
                    header('location: ../home.php'); 
                  }

              } else {
                //jika password salah
                echo "<script>
				alert('Password salah !');
				document.location='login.php';
		  </script>";
              }
          }else{
            echo "<script>
            alert('Login gagal!');
            document.location='login.php';
      </script>";
          }
      }
?>