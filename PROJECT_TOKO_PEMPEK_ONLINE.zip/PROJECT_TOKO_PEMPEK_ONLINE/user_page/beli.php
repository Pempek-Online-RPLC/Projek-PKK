<?php 
session_start();
if(!isset($_SESSION['login_user'])) {
	echo "<script>
			alert('Login untuk membeli');
			document.location='../home.php';
	  </script>";
  }
$id_menu = $_GET['id_menu'];

if (isset($_SESSION['pesanan'][$id_menu]))
{
	$_SESSION['pesanan'][$id_menu]+=1;
}

else 
{
	$_SESSION['pesanan'][$id_menu]=1;
}

echo "<script>alert('Produk telah masuk ke keranjang belanja anda');</script>";
echo "<script>location= 'produk.php'</script>";

 ?>