<html>
	<head>
		<title>Register</title>
		<link rel="stylesheet" href="css/pwpb15.css">
	</head>
	<body>
		<div class="card">
			<center><h2>Halaman Registrasi</h2></center>
			<form method="post" action="submit_register.php">
				<table border="0">
					<tr>
						<td>Masukkan Username </td>
						<td><input name="username" type="text"></td>
					</tr>
					<tr>
						<td>Masukkan Password </td>
						<td><input name="pass1" type="password"></td>
					</tr>
					<tr>
						<td>Ulangi Password </td>
						<td><input name="pass2" type="password"></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td><input type="submit" name="Submit" value="Submit"></td>
					</tr>
				</table>
			</form>
		</div>
	</body>
</html>