<html>
	<head>
		<title>Logout</title>
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="halaman">			
			<?php 
				//menjalankan session : selalu diletakkan di awal
				session_start();
				//menghapus session username dan level
				unset($_SESSION['username']);
				unset($_SESSION['level']);
				//mengapus semua session dari browser
				session_destroy();
				echo "<center><h1>Anda sudah logout</h1></center>";
				echo "<center><p><a href='login.php'>Login Kembali</a></p></center>";
			?>
		</div>
	</body>
</html>