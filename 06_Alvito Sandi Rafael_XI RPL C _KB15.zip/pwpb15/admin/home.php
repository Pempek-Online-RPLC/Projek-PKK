<div class="halaman">
	<?php 
				//menjalankan session : selalu diletakkan di awal
				session_start();
				if (isset($_SESSION['level']) && isset($_SESSION['username'])) {
					//jika level admin akan masuk ke halaman admin.php
					if ($_SESSION['level'] == "admin") {
						echo "<center><h3>Ini Halaman Admin</h3></center>";
						echo "Selamat Datang : <b>".$_SESSION['username']."</b><br>";
						echo "Level Anda sebagai : <b>".$_SESSION['level']."</b><br>";
					}
					//jika kondisi level user maka akan diarahkan ke halaman user.php
					else if($_SESSION['level'] == "user"){
						header('location:index_user.php');
					}
				}
	?>
</div>