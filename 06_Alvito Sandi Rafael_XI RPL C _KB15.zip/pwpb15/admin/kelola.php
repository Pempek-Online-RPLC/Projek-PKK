<div class="halaman">
	<!-- isi halaman kelola -->
	<?php 
		include 'koneksi/koneksi1.php';
		if (isset($_GET['page'])) {
			@$aksi = $_GET['aksi'];
			switch ($aksi) {
				case 'value':
					//menampilkan data kelola
				default:
					$query = "SELECT * FROM tb_konten";
					$hasil = mysqli_query($koneksi_db,$query);
	?>
				<center><h2>Halaman Kelola Konten</h2></center>
				<a href="?page=kelola&aksi=tambah">Tambah</a>
				<table border="1" align="center">
					<tr>
						<th>No</th>
						<th>Kategori</th>
						<th>Isi</th>
						<th colspan="3">Action</th>
					</tr>
					<?php 
						$no=1;
						while ($data=mysqli_fetch_array($hasil)) {
					?>
							<tr>
								<td><?php echo $no++;?></td>
								<td><?php echo $data['kategori']; ?></td>
								<td><?php echo $data['isi']; ?></td>
								<td><a href="?page=kelola&aksi=lihat&id=<?php echo $data['id_konten'];?>">View</a></td>
								<td><a href="?page=kelola&aksi=update&id=<?php echo $data['id_konten'];?>">Update</a></td>
								<td><a href="?page=kelola&aksi=delete&id=<?php echo $data['id_konten'];?>" onclick="return confirm('Apakah anda yakin menghapus data?')">Delete</a></td>
							</tr>
							<?php
						}
							?>
				</table>
			<?php 
				break;
				case 'tambah':
					include 'admin/tambah.php';
				break;
				// Lihat data
				case 'lihat':
					include 'admin/lihat.php';
				break;
				// Update data
				case 'update':
					include 'admin/update.php';
				break;
				// Delete data
				case 'delete':
					include 'admin/delete.php';
				break;
			}
		}else{
			include 'admin/home.php';
		}
			?>
</div>