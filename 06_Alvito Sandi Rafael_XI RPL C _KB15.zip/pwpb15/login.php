<html>
	<head>
		<title>Login</title>
		<link rel="stylesheet" href="css/pwpb15.css">
	</head>
	<body>
		<div class="card">			
			<center><h2>Login</h2></center>
			<form method="post" action="submit_login.php">
				<table border="0">
					<tr>
						<td>Masukkan Username </td>
						<td><input name="username" type="text"></td>
					</tr>
					<tr>
						<td>Masukkan Password </td>
						<td><input name="pass" type="password"></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td><input type="submit" name="Submit" value="Submit"></td>
					</tr>
				</table>
			</form>
		</div>
	</body>
</html>