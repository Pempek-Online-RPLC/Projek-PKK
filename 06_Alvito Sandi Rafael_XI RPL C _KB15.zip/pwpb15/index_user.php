<!DOCTYPE html>
<html>
<head>
	<title>Membuat Halaman Web Dinamis Dengan PHP</title>
	<!-- menghubungkan dengan file css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- menghubungkan dengan file jquery - misalkan ada -->
	<script type="text/javascript" src="jquery,js"></script>
</head>
<body>
	<div class="content">
		<header>
			<h1 class="judul">INI ADALAH HEADER</h1>
			<h3 class="deskripsi">Membuat Halaman Web Dinamis Dengan PHP</h3>
		</header>
		<div class="menu">
			<ul>
				<li><a href="index_user.php?page=home">HOME</a></li>
				<li><a href="index_user.php?page=tentang">TENTANG</a></li>
				<li><a href="index_user.php?page=tutorial">TUTORIAL</a></li>
				<li><a href="index_user.php?page=lihat_data">LIHAT DATA</a></li>
				<li><a href="index_user.php?page=logout">LOGOUT</a></li>
			</ul>
		</div>
		<div class="badan">
			<?php 
				//pemanggilan halaman dengan switch...case...
				if (isset($_GET['page'])) {
					$page = $_GET['page'];
					switch ($page) {
						case 'home':
							include 'user/home.php';
							break;
						case 'tentang':
							include 'user/tentang.php';
							break;
						case 'tutorial':
							include 'user/tutorial.php';
							break;
						case 'lihat_data':
							include 'user/lihat_data.php';
							break;
						case 'logout':
							include 'user/logout.php';
							break;		
						default:
							echo "<center><h3>Maaf, Halaman tidak ditemukan !</h3></center>";
							break;
					}
				}else{
					include 'user/home.php';
				}
			?>
		</div>
		<footer>
			Ini adalah footer
		</footer>
	</div>
</body>
</html>