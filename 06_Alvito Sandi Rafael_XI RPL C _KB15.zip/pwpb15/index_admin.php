<!DOCTYPE html>
<html>
<head>
	<title>Membuat Halaman Web Dinamis Dengan PHP</title>
	<!-- menghubungkan dengan file css -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- menghubungkan dengan file jquery - misalkan ada -->
	<script type="text/javascript" src="jquery,js"></script>
</head>
<body>
	<div class="content">
		<header>
			<h1 class="judul">INI ADALAH HEADER</h1>
			<h3 class="deskripsi">Membuat Halaman Web Dinamis Dengan PHP</h3>
		</header>
		<div class="menu">
			<ul>
				<li><a href="index_admin.php?page=home">HOME</a></li>
				<li><a href="index_admin.php?page=tentang">TENTANG</a></li>
				<li><a href="index_admin.php?page=tutorial">TUTORIAL</a></li>
				<li><a href="index_admin.php?page=kelola">KELOLA</a></li>
				<li><a href="index_admin.php?page=logout">LOGOUT</a></li>
			</ul>
		</div>
		<div class="badan">
			<?php 
				//pemanggilan halaman dengan switch...case...
				if (isset($_GET['page'])) {
					$page = $_GET['page'];
					switch ($page) {
						case 'home':
							include 'admin/home.php';
							break;
						case 'tentang':
							include 'admin/tentang.php';
							break;
						case 'tutorial':
							include 'admin/tutorial.php';
							break;
						case 'kelola':
							include 'admin/kelola.php';
							break;
						case 'logout':
							include 'admin/logout.php';
							break;		
						default:
							echo "<center><h3>Maaf, Halaman tidak ditemukan !</h3></center>";
							break;
					}
				}else{
					include 'admin/home.php';
				}
			?>
		</div>
		<footer>
			Ini adalah footer
		</footer>
	</div>
</body>
</html>