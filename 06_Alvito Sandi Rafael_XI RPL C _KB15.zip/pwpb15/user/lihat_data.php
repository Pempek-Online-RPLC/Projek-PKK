<div class="halaman">
	<!-- isi halaman kelola -->
	<?php 
		include 'koneksi/koneksi1.php';
		if (isset($_GET['page'])) {
			@$aksi = $_GET['aksi'];
			switch ($aksi) {
				case 'value':
					//menampilkan data kelola
				default:
					$query = "SELECT * FROM tb_konten";
					$hasil = mysqli_query($koneksi_db,$query);
	?>
				<center><h2>Halaman Lihat Konten</h2></center>
				<table border="1" align="center">
					<tr>
						<th>No</th>
						<th>Kategori</th>
						<th>Isi</th>
						<th colspan="3">Action</th>
					</tr>
					<?php 
						$no=1;
						while ($data=mysqli_fetch_array($hasil)) {
					?>
							<tr>
								<td><?php echo $no++;?></td>
								<td><?php echo $data['kategori']; ?></td>
								<td><?php echo $data['isi']; ?></td>
								<td><a href="?page=lihat_data&aksi=lihat&id=<?php echo $data['id_konten'];?>">View</a></td>
							</tr>
							<?php
						}
							?>
				</table>
			<?php 
				break;
				// Lihat data
				case 'lihat':
					include 'user/lihat.php';
				break;
			}
		}else{
			include 'user/home.php';
		}
			?>
</div>