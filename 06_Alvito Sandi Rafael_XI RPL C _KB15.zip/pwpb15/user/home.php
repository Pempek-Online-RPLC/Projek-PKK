<div class="halaman">
	<?php 
		//menjalankan session : selalu diletakkan di awal
		session_start();
		if (isset($_SESSION['level']) && isset($_SESSION['username'])) {
			//ini adalah halaman dengan level user
			if ($_SESSION['level'] == "user") {
				echo "<center><h3>Ini Halaman User</h3></center>";
				echo "Selamat Datang : <b>".$_SESSION['username']."</b><br>";
				echo "Level Anda sebagai : <b>".$_SESSION['level']."</b></br>";
				}
				else{
					echo "Anda belum terdaftar sebagai User";
				}
		}
	?>
</div>